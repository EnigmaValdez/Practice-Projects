﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    End Sub



    Private Sub Label6_Click(sender As Object, e As EventArgs) Handles lblAverage.Click

    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click

    End Sub

    Private Sub TextB_TextChanged(sender As Object, e As EventArgs) Handles txtTest1.TextChanged

    End Sub

    Private Sub btnCalcAvg_Click(sender As Object, e As EventArgs) Handles btnCalcAvg.Click
        ' Read score inputs
        Dim Test1 As Integer = txtTest1.Text
        Dim Test2 As Integer = txtTest2.Text
        Dim Test3 As Integer = txtTest3.Text
        Dim Average As Integer = (Test1 + Test2 + Test3) / 3 'Calculate Average 

        ' Display average
        lblAverage.Text = Average

        Dim Grade As String

        'Assign grade based on average
        If Average < 60 Then
            Grade = "F"
            lblGrade.Text = Grade
        ElseIf Average < 70 Then
            Grade = "D"
            lblGrade.Text = Grade
        ElseIf Average < 80 Then
            Grade = "C"
            lblGrade.Text = Grade
        ElseIf Average < 90 Then
            Grade = "B"
            lblGrade.Text = Grade
        ElseIf Average < 100 Then
            Grade = "A"
            lblGrade.Text = Grade
        End If


        ' Display grade
        lblGrade.Text = Grade
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ' Clear textboxes and labels
        txtTest1.Text = ""
        txtTest2.Text = ""
        txtTest3.Text = ""
        lblAverage.Text = ""
        lblGrade.Text = ""
    End Sub

End Class
