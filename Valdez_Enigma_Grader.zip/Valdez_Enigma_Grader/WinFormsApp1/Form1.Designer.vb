﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        Label4 = New Label()
        Label5 = New Label()
        lblAverage = New Label()
        lblGrade = New Label()
        txtTest1 = New TextBox()
        txtTest2 = New TextBox()
        txtTest3 = New TextBox()
        btnCalcAvg = New Button()
        btnClear = New Button()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(36, 32)
        Label1.Name = "Label1"
        Label1.Size = New Size(86, 41)
        Label1.TabIndex = 0
        Label1.Text = "Test1"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(36, 88)
        Label2.Name = "Label2"
        Label2.Size = New Size(86, 41)
        Label2.TabIndex = 1
        Label2.Text = "Test2"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(36, 144)
        Label3.Name = "Label3"
        Label3.Size = New Size(86, 41)
        Label3.TabIndex = 2
        Label3.Text = "Test3"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Location = New Point(36, 221)
        Label4.Name = "Label4"
        Label4.Size = New Size(125, 41)
        Label4.TabIndex = 3
        Label4.Text = "Average"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Location = New Point(36, 289)
        Label5.Name = "Label5"
        Label5.Size = New Size(98, 41)
        Label5.TabIndex = 4
        Label5.Text = "Grade"
        ' 
        ' lblAverage
        ' 
        lblAverage.BorderStyle = BorderStyle.Fixed3D
        lblAverage.Location = New Point(202, 229)
        lblAverage.Name = "lblAverage"
        lblAverage.Size = New Size(95, 37)
        lblAverage.TabIndex = 5
        ' 
        ' lblGrade
        ' 
        lblGrade.BorderStyle = BorderStyle.Fixed3D
        lblGrade.Location = New Point(202, 298)
        lblGrade.Name = "lblGrade"
        lblGrade.Size = New Size(95, 48)
        lblGrade.TabIndex = 6
        ' 
        ' txtTest1
        ' 
        txtTest1.Location = New Point(202, 32)
        txtTest1.Name = "txtTest1"
        txtTest1.Size = New Size(84, 47)
        txtTest1.TabIndex = 7
        ' 
        ' txtTest2
        ' 
        txtTest2.Location = New Point(202, 88)
        txtTest2.Name = "txtTest2"
        txtTest2.Size = New Size(84, 47)
        txtTest2.TabIndex = 8
        ' 
        ' txtTest3
        ' 
        txtTest3.Location = New Point(202, 141)
        txtTest3.Name = "txtTest3"
        txtTest3.Size = New Size(84, 47)
        txtTest3.TabIndex = 9
        ' 
        ' btnCalcAvg
        ' 
        btnCalcAvg.Location = New Point(161, 380)
        btnCalcAvg.Name = "btnCalcAvg"
        btnCalcAvg.Size = New Size(188, 58)
        btnCalcAvg.TabIndex = 10
        btnCalcAvg.Text = "Calculate Average"
        btnCalcAvg.UseVisualStyleBackColor = True
        ' 
        ' btnClear
        ' 
        btnClear.Location = New Point(462, 380)
        btnClear.Name = "btnClear"
        btnClear.Size = New Size(188, 58)
        btnClear.TabIndex = 11
        btnClear.Text = "Clear"
        btnClear.UseVisualStyleBackColor = True
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(17F, 41F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(btnClear)
        Controls.Add(btnCalcAvg)
        Controls.Add(txtTest3)
        Controls.Add(txtTest2)
        Controls.Add(txtTest1)
        Controls.Add(lblGrade)
        Controls.Add(lblAverage)
        Controls.Add(Label5)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Name = "Form1"
        Text = "<Enigma Valdez> - Grader"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents lblAverage As Label
    Friend WithEvents lblGrade As Label
    Friend WithEvents txtTest1 As TextBox
    Friend WithEvents txtTest2 As TextBox
    Friend WithEvents txtTest3 As TextBox
    Friend WithEvents btnCalcAvg As Button
    Friend WithEvents btnClear As Button

End Class
